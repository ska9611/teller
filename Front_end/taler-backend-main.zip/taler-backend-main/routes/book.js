require("dotenv").config();
const express = require("express");
const router = express.Router();
const mysql = require("mysql2/promise");

const mysqlConfig = {
	host: process.env.mysql_host,
	user: process.env.mysql_user,
	password: process.env.mysql_password,
	database: process.env.mysql_database,
};
const pool = mysql.createPool(mysqlConfig);

// 배너페이지를 위한 랜덤 책 5권 조회
router.get("/", async (req, res) => {
	try {
		console.log("hi");
		const connection = await pool.getConnection();
		const [randomBooks] = await connection.query(
			"SELECT * FROM books ORDER BY RAND() LIMIT 5"
		);
		connection.release();

		res.json({ books: randomBooks });
	} catch (error) {
		console.error("Error fetching books:", error);
		res.status(500).send("Internal Server Error");
	}
});

router.get("/main", async (req, res) => {
	try {
		// MySQL 연결 풀에서 연결 가져오기
		const connection = await pool.getConnection();

		// 모든 책 정보를 조회하는 쿼리 실행
		const [books] = await connection.query(
			"SELECT * FROM books ORDER BY RAND() LIMIT 50"
		);

		// 연결 반환
		connection.release();

		// 클라이언트에게 JSON 형식으로 책 정보 전송
		res.json(books);
	} catch (error) {
		console.error("Error fetching books:", error);
		res.status(500).send("Internal Server Error");
	}
});

router.get("/search", async (req, res) => {
	const keyword = req.query.keyword;
	const query =
		"SELECT * FROM books WHERE title LIKE '%" +
		keyword +
		"%' OR author LIKE '%" +
		keyword +
		"%' OR publisher LIKE '%" +
		keyword +
		"%'";
	try {
		// MySQL 연결 풀에서 연결 가져오기
		const connection = await pool.getConnection();

		// 책 검색 쿼리 실행
		const [result] = await connection.query(query);

		// 연결 반환
		connection.release();
		res.json(result);
	} catch (error) {
		console.error("Error searching books:", error);
		res.status(500).send("Internal Server Error");
	}
});

// 특정 이름을 가진 책 조회
router.get("/:isbn", async (req, res) => {
	const searchTerm = req.params.isbn;
	try {
		const connection = await pool.getConnection();
		const [result] = await connection.query(
			"SELECT * FROM books WHERE isbn = ?",
			[`${searchTerm}`]
		);
		connection.release();
		const resData = result.find((book) => book.isbn === searchTerm);
		res.json(resData);
	} catch (error) {
		console.error("Error searching books:", error);
		res.status(500).send("Internal Server Error");
	}
});

module.exports = router;
