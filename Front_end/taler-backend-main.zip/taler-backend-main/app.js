const express = require("express");
const app = express();
const port = 3000;
const cors = require("cors");
var bodyParser = require("body-parser");
var session = require("express-session");

require("dotenv").config();

const mongoose = require("mongoose");
const axios = require("axios");
const mysql = require("mysql2/promise");
console.log("Connected to PlanetScale!");

// MySQL 연결 설정
const mysqlConfig = {
	host: "192.168.10.51",
	user: "admin",
	password: "admin1@34",
	database: "Tale.er",
};
const pool = mysql.createPool(mysqlConfig);

const path = require("path");
const corsOptions = {
	withCredentials: true,
};
app.set("view engine", "ejs");
app.set("views", "./views");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.json());
app.use(cors(corsOptions));

app.use("/static", express.static("public"));
// 이미 선언된 session 변수를 사용하도록 수정

//사용자 세션 인증 쿠키
app.use(
	session({
		secret: "tale.er",
		cookie: { maxAge: 60000 },
		resave: true,
		saveUninitialized: true,
	})
);

app.use((req, res, next) => {
	// user 객체 초기화
	res.locals.user = null;

	// 세션에서 사용자 정보를 가져와서 user 객체 설정
	if (req.session.user) {
		res.locals.user = {
			ID: req.session.user.ID,
			name: req.session.user.name,
			nickname: req.session.user.nickname,
			email: req.session.user.email,
			phone: req.session.user.phone,
			address: req.session.user.address,
			// 필요한 다른 사용자 정보도 추가할 수 있음
		};
	}

	// 다음 미들웨어로 이동
	next();
});
app.use(express.static(path.join(__dirname, "./dist")));
app.get("/", (req, res) => {
	res.sendFile(path.join(__dirname, "./dist", "index.html"));
});

// 로그인
app.post("/login", async (req, res) => {
	const { email, password } = req.body;
	if (email && password) {
		try {
			// Check if user exists with the provided credentials
			const [users] = await pool.query(
				"SELECT email, name, nickname, phone, gender, address FROM Users_info WHERE email = ? AND password = ?",
				[email, password]
			);

			if (users.length === 1) {
				// User exists and credentials are correct
				// 세션에 사용자 정보를 저장합니다.
				const user = users[0];
				req.session.user = user;
				console.log("Logged in user:", user); // 세션 데이터 출력
				return res.json({ user: req.session.user });
			} else {
				// User does not exist or credentials are incorrect
				return res
					.status(401)
					.json({ error: "아이디 또는 비밀번호가 잘못되었습니다." });
			}
		} catch (error) {
			console.error("Error during login:", error);
			return res.status(500).json({ error: "로그인 중 오류가 발생했습니다." });
		}
	} else {
		return res.status(400).json({ error: "아이디와 비밀번호를 입력해주세요." });
	}
});

// 로그아웃 처리
app.get("/logout", (req, res) => {
	// 세션을 삭제합니다.
	req.session.destroy((err) => {
		if (err) {
			console.error("Error destroying session:", err);
			return res
				.status(500)
				.json({ error: "세션 삭제 중 오류가 발생했습니다." });
		}
		// 로그인 페이지로 리다이렉트합니다.
		res.redirect("/login");
	});
});

app.get("/Users_info", (req, res) => {
	res.render("Users_info");
});

// 회원가입 처리
app.post("/Users_infoProc", async (req, res) => {
	const { email, password, name, nickname, phone, gender, address } = req.body;

	// 특수 문자가 포함되어 있는지 확인하기 위한 정규 표현식
	const specialCharacterRegex = /[!@#$%^&*(),.?":{}|<>]/;

	if (password && email) {
		try {
			// Check if user ID or email already exists
			const [existingUsers] = await pool.query(
				"SELECT * FROM Users_info WHERE email = ?",
				[email]
			);

			if (existingUsers.length > 0) {
				// User ID or email already exists, show a warning message
				res.send(
					'<script>alert("이미 존재하는 이메일입니다."); location.href="/Users_info";</script>'
				);
				return;
			}

			// 특수 문자가 포함되어 있는지 확인
			if (!specialCharacterRegex.test(password)) {
				res.send(
					'<script>alert("비밀번호에는 특수 문자를 최소 한 개 이상 포함해야 합니다."); location.href="/Users_info";</script>'
				);
				return;
			}
			// Check if gender value is valid ENUM value
			const validGenders = ["male", "female"]; // ENUM으로 정의된 값들
			if (!validGenders.includes(gender)) {
				res.send(
					'<script>alert("올바른 성별 값을 입력해주세요."); location.href="/Users_info";</script>'
				);
				return;
			}
			// Proceed with the registration if everything is okay
			await pool.query(
				"INSERT INTO Users_info (email, password, name, nickname, phone, gender, address) VALUES (?, ?, ?, ?, ?, ?, ?)",
				[email, password, name, nickname, phone, gender, address]
			);

			console.log("Inserted one record into Users_info table.");

			// Set session data for the user
			req.session.user = {
				email,
				password,
				name,
				nickname,
				phone,
				gender,
				address,
				// Add other necessary fields here
			};

			console.log("Session data:", req.session.user); // 세션 데이터 출력
			return res.json({ user: req.session.user });
		} catch (error) {
			console.error("Error during registration:", error);
			return res.send(
				'<script>alert("회원가입 중 오류가 발생했습니다."); location.href="/Users_info";</script>'
			);
		}
	} else {
		return res.send(
			'<script>alert("모든 정보를 입력해주세요."); location.href="/Users_info";</script>'
		);
	}
});

// 사용자 정보 조회
app.post("/GetInfo", async (req, res) => {
	req.body.email;
});
/// 회원 정보 수정 처리
//마이페이지 정보 수정
app.post("/Users_infoUpdate", async (req, res) => {
	try {
		console.log("edit");
		// 클라이언트로부터 주소, 전화번호, 닉네임을 요청 본문에서 가져옴
		const { address, phone, nickname } = req.body;
		console.log("Received address:", address);
		console.log("Received phone:", phone);
		console.log("User nickname:", nickname);
		// 데이터베이스 쿼리 실행
		const result = await pool.query(
			"UPDATE Users_info SET address = ?, phone = ? WHERE nickname = ?",
			[address, phone, nickname]
		);

		// 여기서 result와 result2를 적절히 처리하고 클라이언트에게 응답을 보낼 수 있음
		res.status(200).send("Update successful");
	} catch (error) {
		// 에러 처리
		console.error("Error updating user info:", error.message);
		return res.status(500).send("Error updating user info");
	}
});

// 관리자 로그인 페이지 렌더링
app.get("/admin/login", (req, res) => {
	res.render("admin_login");
});

// 관리자 로그인 처리
app.post("/admin/login", (req, res) => {
	const { username, password } = req.body;
	// 관리자 인증 로직 수행
	if (username === "admin" && password === "adminpassword") {
		// 로그인 성공 시 관리자 대시보드 페이지로 리다이렉트
		res.redirect("/admin/dashboard");
	} else {
		// 로그인 실패 시 에러 메시지 표시
		res.render("admin_login", { error: "Invalid username or password" });
	}
});

// 관리자 대시보드 페이지 렌더링
app.get("/admin/dashboard", async (req, res) => {
	try {
		// Users_info 테이블에서 사용자 정보 조회
		const [usersResult] = await pool.query(
			"SELECT email, password, name, nickname, phone, gender , address FROM Users_info"
		);
		const users = usersResult.length > 0 ? usersResult : [];

		res.render("admin_dashboard", { users: users });
	} catch (error) {
		console.error("Error fetching data:", error);
		res.render("admin_dashboard", { error: "Error fetching data" });
	}
});

app.post("/admin/deleteUser", async (req, res) => {
	const userId = req.body.userId;
	try {
		// 회원 정보 삭제
		await pool.query("DELETE FROM Users_info WHERE email = ?", [useremail]);
		res.redirect("/admin/dashboard");
	} catch (error) {
		console.error("Error deleting user:", error);
		res.render("admin_dashboard", { error: "Error deleting user" });
	}
});

// 사용자 검색 처리
app.post("/admin/searchUsers", async (req, res) => {
	const searchKeyword = req.body.searchKeyword;
	try {
		// Users_info 테이블에서 검색어와 일치하는 사용자 정보 조회
		const [usersResult] = await pool.query(
			"SELECT email, name, nickname, phone, gender, address FROM Users_info WHERE email = ?",
			[searchKeyword, searchKeyword]
		);
		const users = usersResult.length > 0 ? usersResult : [];

		res.render("admin_dashboard", { users, subscribers: [] });
	} catch (error) {
		console.error("Error searching users:", error);
		res.render("admin_dashboard", { error: "Error searching users" });
	}
});

app.post("/admin/sendMessageToAll", async (req, res) => {
	const message = req.body.message;
	try {
		// 모든 사용자에게 메시지를 보내는 로직 추가
		// 이 부분은 데이터베이스에서 모든 사용자를 조회하고 각 사용자에게 메시지를 전송하는 로직이 포함됩니다. -> 이 부분을 어떻게 구현할 지 고민중
		res.send("Message sent to all users successfully.");
	} catch (error) {
		console.error("Error sending message to all users:", error);
		res.status(500).send("Error sending message to all users");
	}
});

app.get("/book", async (req, res) => {
	try {
		const connection = await pool.getConnection();
		const [randomBooks] = await connection.query(
			"SELECT * FROM books ORDER BY RAND() LIMIT 5"
		);
		connection.release();
		res.json({ books: randomBooks });
	} catch (error) {
		console.error("Error fetching books:", error);
		res.status(500).send("Internal Server Error");
	}
});
app.get("/book/main", async (req, res) => {
	try {
		// MySQL 연결 풀에서 연결 가져오기
		const connection = await pool.getConnection();
		// 모든 책 정보를 조회하는 쿼리 실행
		const [books] = await connection.query(
			"SELECT * FROM books ORDER BY RAND() LIMIT 50"
		);
		// 연결 반환
		connection.release();
		// 클라이언트에게 JSON 형식으로 책 정보 전송
		res.json(books);
	} catch (error) {
		console.error("Error fetching books:", error);
		res.status(500).send("Internal Server Error");
	}
});
app.get("/book/search", async (req, res) => {
	const keyword = req.query.keyword;
	const query =
		"SELECT * FROM books WHERE title LIKE '%" +
		keyword +
		"%' OR author LIKE '%" +
		keyword +
		"%' OR publisher LIKE '%" +
		keyword +
		"%'";
	try {
		// MySQL 연결 풀에서 연결 가져오기
		const connection = await pool.getConnection();
		// 책 검색 쿼리 실행
		const [result] = await connection.query(query);
		// 연결 반환
		connection.release();
		res.json(result);
	} catch (error) {
		console.error("Error searching books:", error);
		res.status(500).send("Internal Server Error");
	}
});
// 특정 이름을 가진 책 조회
app.get("/book/:isbn", async (req, res) => {
	const searchTerm = req.params.isbn;
	try {
		const connection = await pool.getConnection();
		const [result] = await connection.query(
			"SELECT * FROM books WHERE isbn = ?",
			[`${searchTerm}`]
		);
		connection.release();
		const resData = result.find((book) => book.isbn === searchTerm);
		res.json(resData);
	} catch (error) {
		console.error("Error searching books:", error);
		res.status(500).send("Internal Server Error");
	}
});

app.get("*", async (req, res) => {
	res.sendFile(path.join(__dirname, "./dist", "index.html"));
});
app.listen(port, () => {
	console.log(`서버가 실행되었습니다. 접속주소 :http://localhost:${port}`);
});
